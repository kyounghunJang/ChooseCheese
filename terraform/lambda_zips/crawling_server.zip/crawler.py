
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from confluent_kafka import Producer


from jose import JWTError, jwt
import json
import boto3
import os
import time



SECRET_KEY = os.getenv('SECRET_KEY')
ALGORITHM = os.getenv('ALGORITHM')
dynamodb = boto3.client('dynamodb')




def delivery_report(self,err, msg):
    if err is not None:
        print(f"Message delivery failed: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")
        print(f"Delivery took: {time.time() - msg.timestamp()[1]} seconds")


def producing_kafka(self,image,new_filename):
    conf = {'bootstrap.servers': '172.22.0.8:9092'}
    producer = Producer(conf) 
    producer.produce('test',value=image, callback=self.delivery_report)
    producer.flush()
    os.remove(os.path.join(self.download_dir, new_filename))

def lambda_handler(event, context):
    jwt_code = event['headers']['Authorization']
    token = jwt_code.split(" ")[1]
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = decoded['sub']
    
        json_string = event['body']
        data = json.loads(json_string)
        original_url = data['url']


        return {
            'statusCode': 200,
            'body': json.dumps(result)  # JSON 직렬화를 추가했습니다.
        }

    except JWTError as e:
        print("JWTError:", str(e))
        return {
            'statusCode': 401,
            'body': 'Unauthorized: Token verification failed'
        }
